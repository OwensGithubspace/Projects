import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


/**
 * This is the driver class that creates the game window and creates the checkerboard object
 * @author Owen Reece
 *
 */
public class CheckerGame extends JFrame {

	private char [][] boardStatus = new char[][]{
		{'e','b','e','b','e','b','e','b'},
		{'b','e','b','e','b','e','b','e'},
		{'e','b','e','b','e','b','e','b'},
		{'e','e','e','e','e','e','e','e'},
		{'e','e','e','e','e','e','e','e'},
		{'r','e','r','e','r','e','r','e'},
		{'e','r','e','r','e','r','e','r'},
		{'r','e','r','e','r','e','r','e'}
	};
	static final int WIDTH = 505;
	static final int HEIGHT = 585;

	
	/**
	 * The constructor for the jframe that creates the game window and the appropriate objects
	 * @throws IllegalCheckerboardArgumentException The exception thrown if a checkerpiece object has an illegal argument
	 */
	public CheckerGame() throws IllegalCheckerboardArgumentException {
		setTitle("Checker Game");
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel statusBar = new JPanel();
		JLabel numOfCheckers = new JLabel("Black Checkers remaining: 12  Red Checkers remaining: 12");
		JLabel name = new JLabel("This game was developed by Owen Reece");
		statusBar.setLayout(new GridLayout(2,1));
		statusBar.add(numOfCheckers);
		statusBar.add(name);
		createMenuBar();

		//create checkerboard object
		CheckerBoard board = new CheckerBoard(boardStatus);
		//add to frame
		add(board);
		add(statusBar, BorderLayout.SOUTH);
	}

	
	/**
	 * A method to create the menubar for the program
	 */
	private void createMenuBar() {
		JMenuBar menubar = new JMenuBar();
		this.setJMenuBar(menubar);


		//the game menu
		JMenu gameMenu =new JMenu("Game");
		menubar.add(gameMenu);

		JMenuItem newItem = new JMenuItem("New");
		gameMenu.add(newItem);

		newItem.addActionListener(new MenuItemActionPerformed());

		//the stuff in a menu
		JMenuItem exitItem = new JMenuItem("Exit");

		gameMenu.add(exitItem);
		//give it a listener
		exitItem.addActionListener(new MenuItemActionPerformed());

		//the help menu
		JMenu helpMenu = new JMenu("Help");
		menubar.add(helpMenu);

		JMenuItem rulesItem = new JMenuItem("Checker Game Rules");
		helpMenu.add(rulesItem);

		rulesItem.addActionListener(new MenuItemActionPerformed());

		//the stuff in a menu
		JMenuItem aboutItem = new JMenuItem("About Checker Game App");

		helpMenu.add(aboutItem);
		//give it a listener
		aboutItem.addActionListener(new MenuItemActionPerformed());

	}

	//what to do for when menuitem is selected 
	/**
	 * The actionListener for menuitems
	 * @author Owen Reece
	 *
	 */
	class MenuItemActionPerformed implements ActionListener{

		@Override
		/**
		 * The required class from the ActionListener interface
		 */
		public void actionPerformed(ActionEvent e) {
			String item = e.getActionCommand();

			if(item.equals("Exit")) {
				System.exit(0);
			}
		}

	}

	/**
	 * The main method that creates the checkergame frame and makes it visible
	 * @param args String arguments
	 * @throws IllegalCheckerboardArgumentException The exception thrown if a checkerpiece object has an illegal argument
	 */
	public static void main(String[] args) throws IllegalCheckerboardArgumentException {
		JFrame game = new CheckerGame();
		game.setVisible(true);

	}

}
