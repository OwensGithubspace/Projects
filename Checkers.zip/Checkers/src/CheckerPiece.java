import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.JFrame;
//checkerpiece should be done?
/**
 * This class actually draws each individual piece and square
 * @author Owen Reece
 *
 */
public class CheckerPiece extends JComponent {

	private char status;
	private int row, column;
	static final int SQUARELENGTH = 60;
	static final int CHECKERLENGTH = 40;
	/**
	 * This method is the constructor for each checkerpiece object and throws an exception if a checker has an illegal value
	 * @param row The row of the space
	 * @param column The column of the space
	 * @param status The status of if a space is empty or has a checkerpiece on it
	 * @throws IllegalCheckerboardArgumentException The exception thrown if an illegal argument is given
	 */
	public CheckerPiece(int row, int column, char status) throws IllegalCheckerboardArgumentException {

		if((row < 0) || (row > 7) || (column < 0) || (column > 7) ||
				((status != 'e') && (status != 'b') && (status != 'r'))){
			throw new IllegalCheckerboardArgumentException("The balance cannot be negative.");
		}

		this.status = status;
		this.row = row;
		this.column = column;
		//this.setBackground(Color.BLUE);
		//repaint();
	}

	@Override
	/**
	 * This method calls the method to draw each piece and square
	 * @param g 
	 */
	public void paintComponent(Graphics g) {
		drawBoard(g);
	}

	/**
	 * This method draws every square and checkerpiece accordingly
	 * @param g 
	 */
	private void drawBoard(Graphics g) {
		//draw it white or green depending on the row and column
		//g.setColor(Color.BLUE);
		//g.fillRect(0, 0, 60, 60);
		if( status == 'e') {
			if((((row + 1) % 2 == 1) && ((column + 1) % 2 == 1)) ||
					(((row + 1) % 2 == 0) && ((column + 1) % 2 == 0))){
				g.setColor(Color.WHITE);
			}
			else {
				g.setColor(Color.GREEN);
			}

			g.fillRect(0, 0, SQUARELENGTH, SQUARELENGTH);
			//System.out.println(row + " " + column);

		}
		else if( status == 'b') {
			//status is black
			g.setColor(Color.GREEN);
			g.fillRect(0,0, SQUARELENGTH, SQUARELENGTH);
			g.setColor(Color.BLACK);
			g.fillOval(9,9,CHECKERLENGTH,CHECKERLENGTH);
		}
		if( status == 'r') {
			//status 
			g.setColor(Color.GREEN);
			g.fillRect(0, 0, SQUARELENGTH, SQUARELENGTH);
			g.setColor(Color.RED);
			g.fillOval(9,9,CHECKERLENGTH,CHECKERLENGTH);
		}

	}

}

