import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

/**
 * The class for the checkerboard panel that has all the checkerpiece objects 
 * @author Owen Reece
 *
 */
public class CheckerBoard extends JPanel {
	//board status has been passed at this point WITH ITS VALUES
	private char[][] boardStatus = new char [8][8];

	/**
	 * The constructor for the checkerboard panel that has all the checkerpiece objects
	 * @param boardStatus The character array that represents the board
	 */
	public CheckerBoard(char[][] boardStatus) {
		this.boardStatus = boardStatus;
		this.setLayout(new GridLayout(8,8));
		int j;
		for(int i = 0; i < 8; i++) {
			j = 0;
			while(j < 8) {
				//add all the checkerpieces to the board
				try {
					//they are already arranged in 8 by 8 so they do not have to be spaced out
					//each grid piece is a checkerpiece object with a drawing board that each has its own
					//0,0 and such separate from all the others
					//create 64 checkerpiece objects on the board
					this.add(new CheckerPiece(i, j, boardStatus[i][j]));
				} catch (IllegalCheckerboardArgumentException e) {

					System.out.print("Error");
					e.printStackTrace();
				}

				j++;
			}

		}
	}



	/**
	 * This method changes the boardstatus for the board and repaints the board
	 * @param boardStatus The new boardStatus array
	 */
	public void setBoardStatus(char[][] boardStatus) {
		this.boardStatus = boardStatus;
		repaint();
	}

	/**
	 * 
	 * @param row The row of the checkerpiece
	 * @param column The column of the checkerpiece
	 * @param status The status of a square(whether it is empty or has a piece in it
	 */
	public void setCheckerPiece(int row, int column, char status) {
		this.boardStatus[row][column] = status;
		repaint();
	}

}
