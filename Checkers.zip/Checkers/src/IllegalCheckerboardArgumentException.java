/**
 * This class is for the exception thrown when a checkerpiece has an illegal argument
 * @author Owen Reece
 *
 */
public class IllegalCheckerboardArgumentException extends Exception {
	/**
	 * This method calls the super class to show that an exception has occurred
	 */
	public IllegalCheckerboardArgumentException() {
		super();

	}
	/**
	 *  This method calls the super class to show that an exception has occurred
	 * @param message The message the superclass will print
	 */
	public IllegalCheckerboardArgumentException(String message) {
		super(message);
	}
}
