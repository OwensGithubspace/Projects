import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Tester {

	public static void main(String[] args) throws FileNotFoundException {
		WordTree wt = new WordTree();
		
//		System.out.println(wt.add("     "));//true
//		System.out.println(wt.contains("    "));//false
//		System.out.println(wt.contains("     "));//true
		
		wt.add("hello");
		System.out.println(wt.wordCount());
		System.out.println(wt.allStartingWith("h"));
		System.out.println(wt.allWords());
		System.out.println(wt.nodeCount());
		System.out.println(wt);
		
		wt.add("hell");
		System.out.println(wt.wordCount());
		System.out.println(wt.allStartingWith("h"));
		System.out.println(wt.allWords());
		System.out.println(wt.nodeCount());
		System.out.println(wt);
		
		wt.remove("hell");
		System.out.println(wt.wordCount());
		System.out.println(wt.allStartingWith("h"));
		System.out.println(wt.allWords());
		System.out.println(wt.nodeCount());
		System.out.println(wt);
		
//		Scanner in = new Scanner(new File("words_alpha.txt"));
//		while(in.hasNextLine()) {
//			String input = in.nextLine();
//			wt.add(input);
//		}
//		in.close();
//		
//		System.out.println(wt.wordCount());
//		System.out.println(wt.nodeCount());
//		System.out.println(wt.lettersSaved());
		
//		System.out.println(wt.allWords());
//		
//		System.out.println(wt.add("sup"));
//		System.out.println(wt.allWords());
//		System.out.println(wt.add("srpa"));
//		System.out.println(wt.allWords());
//		System.out.println(wt.add("super"));
//		System.out.println(wt.allWords());
//		System.out.println(wt.add("cat"));
//		System.out.println(wt.allWords());
//		System.out.println(wt.add("car"));
//		System.out.println(wt.allWords());
//		System.out.println(wt.add(null));
//		System.out.println(wt.allWords());
//		System.out.println(wt.add("catch"));
//		
//		
//		System.out.println(wt.allWords());
//		
//		
//		System.out.println("BABABBABABAB");
//		System.out.println(wt.add(""));
////		
//		System.out.println(wt.contains(""));//false
//		System.out.println(wt.contains(" "));//false
//		System.out.println(wt.contains(null));//false
//		System.out.println(wt.contains("sup"));//true
//		System.out.println(wt.contains("srpa"));
//		System.out.println(wt.contains("super"));
//		System.out.println(wt.contains("cat"));
//		System.out.println(wt.contains("car"));
//		System.out.println(wt.contains("at"));
//		
//		System.out.println(wt.allStartingWith("ca"));
//		System.out.println(wt.remove("sup"));
//		System.out.println(wt.contains("sup"));
////		
//		System.out.println(wt.contains("catch"));//true
		
		
//		wt.remove("catch");
//		System.out.println(wt.contains("cat"));
//		System.out.println(wt.contains("catch"));//false
////		
//System.out.println(wt.allStartingWith(""));
//		
//		System.out.println("ABAAAAAAAAAAAAAAAAAAAAAAA");
//		
//		System.out.println(wt.contains("su"));//all false
//		System.out.println(wt.contains("ball"));
//		System.out.println(wt.contains("supa"));
//		System.out.println(wt.contains("catastrophe"));
//		System.out.println(wt.contains("s"));
//		System.out.println(wt.contains("c"));
//		System.out.println(wt.contains("t"));
//		System.out.println(wt.contains("r"));
		
//		System.out.println(wt.add("catch"));
//		System.out.println(wt.remove(null));
//		
//		System.out.println(wt.allWords());
//		
//		System.out.println(wt.allStartingWith("s"));
//		
//		System.out.println(wt.wordMap());
//		
//		wt.clear();
//		System.out.println(wt);
//		System.out.println(wt.add("catch"));
//		System.out.println(wt);
//		System.out.println(wt);
//		System.out.println(wt.add("cat"));
////		
//		System.out.println("AHHHHH");
//		wt.add("sup");
//		wt.add("srpa");
//		wt.add("super");
//		System.out.println(wt.add("cat"));
//		wt.add("car");
//		wt.add("at");
//		wt.add("catch");
//		System.out.println(wt.allWords());
//		System.out.println(wt.wordCount());
//		System.out.println(wt.nodeCount());
//		System.out.println(wt.lettersSaved());
//		System.out.println(wt.wordMap());
//		wt.clear();
//		System.out.println(wt.allWords());
//		System.out.println(wt.wordCount());
//		System.out.println(wt.nodeCount());
//		System.out.println(wt.lettersSaved());
//		System.out.println(wt.wordMap());
		
		
		
		
		//		System.out.println(wt);
////		System.out.println(wt.remove("catch"));
////		System.out.println(wt);
//		
//System.out.println(wt.allWords());
//		
//		System.out.println(wt.allStartingWith("c"));
//		
//		System.out.println(wt.wordMap());
		
		
//		
//		//System.out.println(wt.wordCount());
//		
//		System.out.println(wt.allWords());
//		
//		System.out.println(wt);
//		
//		//System.out.println(wt.remove("cat"));
//		
//		System.out.println(wt.allWords());
//		
//		System.out.println(wt);

	}

}
