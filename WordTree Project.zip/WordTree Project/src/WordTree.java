import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * A word tree class that contains methods for adding, removing, and searching
 * for different words and letters.
 * 
 * @author Owen Reece
 *
 */
public class WordTree {

	// the root node, the only instance variable
	private Node root;

	// returns a string representation of the entire tree
	public String toString() {
		return root + "";
	}

	/**
	 * Constructs a tree with no words(the root node has to have something in it so
	 * I chose a space
	 */
	public WordTree() {
		root = new Node(' ');
	}

	/**
	 * adds a word to the tree, returning true if the word was added, and false
	 * otherwise (return false if the word is already in the tree). Return false if
	 * the string is empty.
	 * 
	 * @param word The word to be added to the tree.
	 * @return true or false dependent on if the word was added successfully or not.
	 */
	public boolean add(String word) {

		// check if the word already exists, return false if it does
		if (this.contains(word)) {
			return false;
		}

		// otherwise call the recursive helper method
		return add(root, word);

	}

	// private recursive helper method
	private boolean add(Node top, String word) {

		// return false if word is empty or null
		if (word == null || word.isEmpty()) {
			return false;
		} else {
			// otherwise add a new node with one letter of the word to the child of this
			// node
			top.addChild(word.charAt(0));
			// then add a child to that next child as long as the next character in the word
			// exists

			if (word.length() != 1) {// if the next recursive call would not be on an empty string
				add(top.getChild(word.charAt(0)), word.substring(1));// then do recursion with the next character

			} else {// if it would be on an empty string then you are at the end
				top.getChild(word.charAt(0)).isEnd = true;// set the current node to be an end
				return true;
			}
			return true;// it should never reach this I believe, but just to be safe
		}
	}

	/**
	 * return true if the tree contains the word, false otherwise. Return false if
	 * the string is empty.
	 * 
	 * @param word The word to be searched for
	 * @return true or false dependent on if the word was in the tree or not.
	 */
	public boolean contains(String word) {
		if (word == null || word.isEmpty()) {
			return false;
		}
		return contains(root, word);
	}

	// private recursive helper method
	private boolean contains(Node top, String word) {

		boolean result = false;
		// check to see if it has each node with each letter in particular
		for (Node n : top.children) {
			// if the letter for the node is the letter it should be
			if (n.letter == word.charAt(0)) {
				result = true;
				
				// if the next recursive call would not be empty
				if (word.length() != 1) {
					return contains(n, word.substring(1));// call recursion
				} 
				else {
					// the next recursive call is empty which means that the word has been gone through
					// fully to see if it is in the tree, and if it has done that and the letters
					// are all there, but the last letter is not marked as the end of a word, then
					// it is not a word, so return false. 
					//Ex: "super" is in the tree and a word "su" is in the tree but not a word
					// so it would return false
					if (n.isEnd == false) {
						// if the node that was finished on is not the end of a word, it means the word
						// doesn't exist
						result = false;

					}

				}
			}

		}

		return result;

	}

	/**
	 * remove the given word from the tree, returning true if the string existed in
	 * the tree, and false otherwise. Return false if the string is empty. I
	 * recommend saving this method as your last method that you write
	 * 
	 * @param word The word to be removed
	 * @return true or false dependent on if the word was removed successfully or
	 *         not.
	 */
	public boolean remove(String word) {
		// go through the tree, if the end of a word has kids just set isEnd to false,
		// if a word is a PART of the word you are removing(there is an isEnd that isn't
		// the word you were looking for)
		// otherwise, remove the word

		// return false if the string you passed is empty, or the tree doesnt contain
		// the word
		if (this.contains(word) == false || word.isEmpty() == true) {
			return false;
		}

		remove(root, root, word, "");

		return true;

	}

	//private recursive helper method for remove
	private void remove(Node previousNode, Node top, String word, String runningWord) {
		// find the end of the word you are looking for
		// remove the letters starting at that end, until you reach a node that has
		// other child nodes, or a node that is the end of a word, or you reach the root

		// for if there is a word that is literally just the prefix
		if (top == null) {
			return;// nothing to remove
		}

		// if the current node we are dealing with is not the root node, add its letter
		// to the word(this is done so the space in the root node isn't added to the runningWord)
		if (top != root) {
			runningWord = runningWord + top.letter;
		}

		// if we reach the end of a word
		if (top.isEnd == true) {

			// if the word is the word we need to remove, starting at the end
			if ((runningWord).equals(word)) {

				// check if the word end has children
				if (top.children.isEmpty() == false) {
					// if it does: set isEnd equal to false to remove the word
					top.isEnd = false;
					return;
				} else {
					// remove the node by removing it from its parent
					previousNode.children.remove(top);
					return;
				}
			}

		}

		// if we don't then do recursion

		for (Node n : top.children) {
			remove(top, n, word, runningWord);
			// the child has been correctly removed
			if (top.children.contains(n) == false && top != root) {
				
				// if top still has other children, or is the end of another word
				if (top.children.isEmpty() == false || top.isEnd == true) {
					return;// then just return
				} 
				else {
					// otherwise, top has to be removed
					previousNode.children.remove(top);
					return;
				}
			}
		}

		return;

	}

	/**
	 * Return the count of all nodes in the tree not counting the root(that's what
	 * the -1 is for)
	 * 
	 * @return Total number of nodes in the tree except the root
	 */
	public int nodeCount() {
		return nodeCount(root) - 1;
	}
	

	// recursive helper method for nodeCount
	private int nodeCount(Node top) {
		if (top == null) {
			return 0;
		}

		int count = 1; // for itself

		for (Node n : top.children) {
			//call recursion on all of the top node's children
			count += nodeCount(n);
		}

		return count;
	}

	/**
	 * returns the number of words in the tree. Note that this is just like counting
	 * all nodes, but here you only need to count the number of nodes that are
	 * marked as being the end of a word.
	 * 
	 * @return The number of words in the tree
	 */
	public int wordCount() {

		return wordCount(root);
	}

	//recursive helper method for wordCount
	private int wordCount(Node top) {
		int counter = 0;//counter for full words
		for (Node n : top.children) {
			
			//n is the end of a word
			if (n.isEnd == true) {
				counter++;//increase the counter
			}
			// n has children
			if (n.children.isEmpty() == false) {
				counter += wordCount(n);//call recursion 
			}

		}

		return counter;
	}

	/**
	 * This method takes the number of letters in all the words (if those words were
	 * not stored in the tree), and subtracts the number of letters actually used in
	 * the tree to store those words (this second number comes from your
	 * letterCount() method). This is a good way to measure the space efficiency of
	 * your tree.
	 * 
	 * @return The number of letters saved by doing a wordtree, instead of making
	 *         them again.
	 */
	public int lettersSaved() {
		// to get the number of letters in all words you first need a set of all the words
		// then subtract letterCount/nodeCount from it
		Set<String> allWords = allWords();
		int treeLetterCount = nodeCount();
		int setLetterCount = 0;
		for (String s : allWords) {
			// go through all words and add their lengths together
			setLetterCount += s.length();
		}

		return (setLetterCount - treeLetterCount);
	}

	/**
	 * removes all words from the tree. This can be solved with one line of code.
	 */
	public void clear() {
		root.children.clear();
	}

	/**
	 * returns a set of all the words in the tree
	 * 
	 * @return A set of all the words in the tree
	 */
	public Set<String> allWords() {

		Set<String> result = new TreeSet<>();
		allWords(root, result, "");
		return result;
	}

	private void allWords(Node top, Set<String> wordsSoFar, String runningWord) {
		if (top == null) {
			return;// nothing to add to set
		}

		// if we reach the end of a word, put it in the set
		if (top.isEnd == true) {
			// add the full string and the letter of this node
			wordsSoFar.add(runningWord + top.letter);
			// dont return yet in case its part of another word
		}

		// otherwise do recursion
		for (Node n : top.children) {
			// if the current node we are dealing with is not the root node, add its letter
			// to the word(this is done so the space in the root node isn't added to the runningWord) via recursion
			if (top == root) {
				allWords(n, wordsSoFar, runningWord);
			} else {
				allWords(n, wordsSoFar, runningWord + top.letter);
			}
		}

		return;

	}

	/**
	 * returns a set of all the words in the tree that begin with the given prefix.
	 * In the tree shown on the previous page, allStartingWith("CA") should return a
	 * set containing exactly 4 words: CARS, CASH, CAT, CATCHY. If no words begin
	 * with the specified prefix, return an empty set. If prefix is an empty string,
	 * "", return all words.
	 * 
	 * @param prefix The prefix of the words we are looking for
	 * @return the set of all words with that prefix
	 */
	public Set<String> allStartingWith(String prefix) {

		Set<String> result = new TreeSet<>();
		allStartingWith(root, result, "", prefix);
		return result;
	}

	private void allStartingWith(Node top, Set<String> prefixWordsSoFar, String runningWord, String prefix) {
		// for if there is a word that is literally just the prefix
		if (top == null) {
			return;// nothing to add to set
		}

		// if the current node we are dealing with is not the root node, add its letter
		// to the word(this is done so the space in the root node isn't added to the runningWord)
		if (top != root) {
			runningWord = runningWord + top.letter;

		}

		// if we reach the end of a word

		if (top.isEnd == true) {

			// if the word starts with the prefix,add it to the set
			if (runningWord.startsWith(prefix)) {
				prefixWordsSoFar.add(runningWord);
			}
			// dont return yet in case its part of another word
		}

		// otherwise do recursion
		for (Node n : top.children) {
			allStartingWith(n, prefixWordsSoFar, runningWord, prefix);
		}

		return;
	}

	/**
	 * returns a map where the key is a letter of the alphabet, and the value is the
	 * set of all words in the tree that begin with that letter. If there are no
	 * words that begin with a particular letter, don't include it in the map. Solve
	 * this one AFTER solving allStartingWith() above.
	 * 
	 * @return The key value map of letters and corresponding words.
	 */
	public Map<Character, Set<String>> wordMap() {
		Map<Character, Set<String>> wordMap = new TreeMap<>();

		Set<String> words = allWords();
		for (Node n : root.children) {
			char key = n.letter;

			// handle the case where the key is already in the map
			// and when it is not(this case will actually never happen bc the immediate
			// children of the root will never be duplicates
			if (!wordMap.containsKey(key)) {

				// go through all the words to see when to add one
				for (String s : words) {
					if (key == s.charAt(0)) {
						// create set for key to add to map
						Set<String> wordsForThisKey = new TreeSet<>();
						wordsForThisKey.add(s);
						// add the key and its set to the wordmap
						wordMap.put(key, wordsForThisKey);
						break;// do this to avoid creating a set with only one element again and again
					}

				}
				for (String s : words) { // now do this to add all the correct elements to the correct sets
					if (key == s.charAt(0)) {
						wordMap.get(key).add(s);
					}

				}

			}
		}
		return wordMap;
	}

	/**
	 * An inner node class with a set for its children and a boolean for if it is
	 * the end of a word or not.
	 * 
	 * @author Owen Reece
	 *
	 */
	private class Node {
		private char letter;
		private Set<Node> children;
		private boolean isEnd;

		/**
		 * The constructor for the node that gives it a letter, creates a set for its
		 * children, and sets the boolean for if it is the end of a word or not to
		 * false.
		 * 
		 * @param letter The character the node will contain
		 */
		private Node(char letter) {
			this.letter = letter;
			children = new HashSet<>();
			isEnd = false;
		}

		/**
		 * This adds a specified letter as a child node, and returns the resulting new
		 * node. Or, if the letter already exists as a child node, it returns that child
		 * node.
		 * 
		 * @param letter The letter to be added via a node
		 * @return the new node or the already existing child node.
		 */
		private Node addChild(char letter) {
			Node aChild = getChild(letter);
			// if the letter already exists in the children
			if (aChild != null && aChild.letter == letter) {
				return aChild;
			} else {
				Node newNode = new Node(letter);
				children.add(newNode);
				return newNode;
			}

		}

		/**
		 * This method checks if one of the node's child nodes contains the given
		 * letter. If it does, the Node containing that letter is returned. Otherwise,
		 * null is returned. I found this method VERY helpful. For example, if I wanted
		 * to know if CAT is in the tree, I could call root.getChild('C'). If I get back
		 * null, I can stop. But if I get back a Node object, then I know it's the 'C'
		 * node. Then, I can call getChild('A') from the 'C' node, and so on. If I find
		 * the 'T' node, then I just need to check to see if its boolean indicates it is
		 * the end of a word. If it is, then I found CAT.
		 * 
		 * @param letter The letter to search for
		 * @return The node containing the letter we searched for, or null if not found.
		 */
		private Node getChild(char letter) {

			for (Node n : children) {// search just the immediate children
				if (n.letter == letter) {
					return n;
				}

			}

			return null;// if the node is never found return null
		}

		// returns a string representation of node
		public String toString() {
			// children does recursion
			// if its the end of a word, the last letter will be capitalized
			return (isEnd ? (letter + "").toUpperCase() : letter) + " " + children;
		}

	}
}
