let config = {
    host : 'localhost',
    user : 'root',
    password: 'TooManyPasswords20@',
    database: 'bowlingapp'
};

module.exports = config;