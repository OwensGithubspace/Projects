let config = {
    host    : 'localhost',
    user    : 'root',
    password: '!Skeebo0101',
    database: 'bowlingapp'
  };
  
  module.exports = config;