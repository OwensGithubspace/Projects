import { View, Text } from "react-native";

export function SimulationScreen() {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>Simulation Screen</Text>
    </View>
  );
}
